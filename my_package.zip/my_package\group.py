import my_package.exeptions

class Group:

    def __init__(self, number):
        self.number = number
        self.group = set()


    def add_student(self, student):
        if len(self.group) == 10:
            raise my_package.exeptions.MyException("The max studen's num is 10")
        else:
            self.group.add(student)


    def delete_student(self, last_name):
        result = self.find_student(last_name)
        
        if result is None:
            return f"The student '{last_name}' is not found"
        else:
            self.group.discard(result)
            return f"The student '{last_name}' was deleted"
        

    def find_student(self, last_name):
        for i in self.group:
            if i.last_name == last_name:
                return i


    def __str__(self):
        all_students = ''
        for i in self.group:
            all_students += str(i) + "\n\n"

        return f'Number:{self.number} \n {all_students}'