class MyException(Exception):
    pass